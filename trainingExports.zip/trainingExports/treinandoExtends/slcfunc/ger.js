let Func = require('./func')
let Dev = require('./dev')

let f1 = new Func('José', 22, 'Funcionário')
let d1 = new Dev('Joao',20,'Desenvolvedor','JavaScript')

f1.seApresentar()
d1.trabalhar()
